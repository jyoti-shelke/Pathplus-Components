export class Hiv {

  id: number;
  hivI: string;
  hivII: string;
  hivIGp160Env: string;
  hivIGp120Env: string;
  hivIp66Pol: string;
  hivIp55Gag: string;
  hivIp51Pol: string;
  hivIGp41Env: string;
  hivIp39Pol: string;
  hivIp31Gag: string;
  hivIp24Gag: string;
  hivIp55Gag17: string;
  kitUsed: string;
  stripNo: number;
  lotNo: number;
  expDate: string;
  result: string;
  method: string;

  notes: string;

}
