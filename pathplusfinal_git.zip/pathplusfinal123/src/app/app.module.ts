import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CdkTableModule } from '@angular/cdk/table';

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatTreeModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule
} from '@angular/material';
import { AppRoutingModule } from './app-routing.module';
import { HaemogramInputComponent } from './haemogram/haemogram-input/haemogram-input.component';
import { HaemogramListComponent } from './haemogram/haemogram-list/haemogram-list.component';
import { HaemogramService } from './haemogram/haemogram.service';
import { DiabeticService } from './diabetic/diabetic.service';
import { UrineService } from './urine/urine.service';
import { ProthrombinService } from './prothrombin/prothrombin.service';
import { HivService } from './hiv/hiv.service';
import { TreeSidenavComponent } from './sidenav/tree-sidenav/tree-sidenav.component';
import { DiabeticInputComponent } from './diabetic/diabetic-input/diabetic-input.component';
import { HivInputComponent } from './hiv/hiv-input/hiv-input.component';
import { ProthrombinInputComponent } from './prothrombin/prothrombin-input/prothrombin-input.component';
import { UrineInputComponent } from './urine/urine-input/urine-input.component';
import { ReportsOverviewComponent } from './reports/reports-overview/reports-overview.component';
import { MalariartInputComponent } from './malariart/malariart-input/malariart-input.component';
import { MalariartViewComponent } from './malariart/malariart-view/malariart-view.component';
import { MalariartrtService } from './malariart/malariartrt.service';
import { TuberculosisrtInputComponent } from './tuberculosis/tuberculosisrt-input/tuberculosisrt-input.component';
import { TuberculosisrtViewComponent } from './tuberculosis/tuberculosisrt-view/tuberculosisrt-view.component';
import { CardicTroponianInputComponent } from './cardic-troponian/cardic-troponian-input/cardic-troponian-input.component';
import { HbsagrtInputComponent } from './hbsag/hbsagrt-input/hbsagrt-input.component';
import { WidalInputComponent } from './widal/widal-input/widal-input.component';
import { BiochemistryInputComponent } from './biochemistry/biochemistry-input/biochemistry-input.component';
import { UserSearchComponent } from './reports/user-search/user-search.component';
import { HaemogramTestViewComponent } from './haemogram/haemogram-test-view/haemogram-test-view.component';
import { DiabeticViewComponent } from './diabetic/diabetic-view/diabetic-view.component';
import { UrineViewComponent } from './urine/urine-view/urine-view.component';
import { HbsagrtViewComponent } from './hbsag/hbsagrt-view/hbsagrt-view.component';
import { WidalViewComponent } from './widal/widal-view/widal-view.component';
import { BiochemistryViewComponent } from './biochemistry/biochemistry-view/biochemistry-view.component';

@NgModule({
  declarations: [
    AppComponent,
    TreeSidenavComponent,
    HaemogramInputComponent,
    HaemogramListComponent,
    HaemogramTestViewComponent,
    DiabeticInputComponent,
    HivInputComponent,
    ProthrombinInputComponent,
    UrineInputComponent,
    ReportsOverviewComponent,
    MalariartInputComponent,
    TuberculosisrtInputComponent,
    CardicTroponianInputComponent,
    HbsagrtInputComponent,
    WidalInputComponent,
    BiochemistryInputComponent,
    UserSearchComponent,
    MalariartViewComponent,
    TuberculosisrtViewComponent,
    HaemogramTestViewComponent,
    DiabeticViewComponent,
    UrineViewComponent,
    HbsagrtViewComponent,
    WidalViewComponent,
    BiochemistryViewComponent
  ],
  imports: [
    CdkTableModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTreeModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [HaemogramService, DiabeticService, UrineService, ProthrombinService, HivService, MalariartrtService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
