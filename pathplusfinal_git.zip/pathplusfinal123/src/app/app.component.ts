import {ChangeDetectorRef, Component, OnDestroy} from '@angular/core';
import {MediaMatcher} from '@angular/cdk/layout';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnDestroy {

  mobileQuery: MediaQueryList;

  pathNav = [
    {
      title: 'Haemogram',
      link: '/haemograms'
    },
    {
      title: 'Diabetic',
      link: '/diabetic'
    },
    {
      title: 'HIV',
      link: '/hiv'
    },
    {
      title: 'Urine',
      link: '/urine'
    },
    {
      title: 'MalariaRT',
      link: '/malaria'
    }
  ];

  private readonly mobileQueryListener: () => void;

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this.mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addEventListener('change', this.mobileQueryListener);
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeEventListener('change', this.mobileQueryListener);
  }

}
