import { TestBed } from '@angular/core/testing';

import { UrineService } from './urine.service';

describe('UrineService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UrineService = TestBed.get(UrineService);
    expect(service).toBeTruthy();
  });
});
