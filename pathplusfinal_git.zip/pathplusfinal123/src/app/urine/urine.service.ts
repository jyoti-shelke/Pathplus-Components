import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {of} from 'rxjs/observable/of';
import {Urine} from './urine';
import {generateId, URINES} from './urine-mock';

@Injectable({
  providedIn: 'root'
})
export class UrineService {

  urines: Urine[] = URINES;

  constructor() {
  }

  getUrines(): Observable<Urine[]> {
    return of(this.urines);
  }

  getUrine(id: string): Observable<Urine> {
    const urine = this.urines.find(value => '' + value.id === id);
    return of(urine);
  }

  saveUrine(urine: Urine): Observable<string> {
    if (!urine.id) {
      urine.id = generateId(1000);
      this.urines.push(urine);
    } else {
      const index = this.urines.findIndex(value => value.id === urine.id);
      this.urines[index] = urine;
    }
    return of('Test Saved succesfully');
  }

  deleteUrine(id: number): Observable<string> {
    const index = this.urines.findIndex(value => value.id === id);
    this.urines.splice(index, 1);
    return of('Test deleted succesfully');
  }
}