import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UrineViewComponent } from './urine-view.component';

describe('UrineViewComponent', () => {
  let component: UrineViewComponent;
  let fixture: ComponentFixture<UrineViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UrineViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UrineViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
