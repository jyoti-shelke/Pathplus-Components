import { Component, OnInit, OnDestroy } from '@angular/core';
import { Urine } from '../urine';
import { Report } from 'src/app/reports/report';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ReportService } from 'src/app/reports/report.service';
import { UrineService } from '../urine.service';

@Component({
  selector: 'app-urine-view',
  templateUrl: './urine-view.component.html',
  styleUrls: ['./urine-view.component.css']
})
export class UrineViewComponent implements  OnInit, OnDestroy {
  urine = new Urine();
  report = new Report();

  sub: Subscription;

  constructor(private route: ActivatedRoute, private router: Router,
              private urineService: UrineService, private reportService: ReportService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params.id;
      if (id) {
        console.log('Selected id ' + id);
        this.urineService.getUrine(id)
          .subscribe(selectedUrine => this.urine = selectedUrine);

        this.reportService.getReport(id)
          .subscribe(selectedReport => this.report = selectedReport);
      }
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
