export class Urine {

  id: number;
  colour: string;
  apprearance: string;
  ph: string;
  sgravity: string;
  eplCells: number;
  pusCells: number;
  eplCast: number;
  pusCellCast: number;
  crystals: number;
  rbc: number;
  other: number;
  albumin: string;
  sugar: string;
  urobillinogen: string;
  acetone: string;
  bileSalt: string;
  bilePigment: string;
  blood: string;
  notes: string;

}
