import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UrineInputComponent } from './urine-input.component';

describe('UrineInputComponent', () => {
  let component: UrineInputComponent;
  let fixture: ComponentFixture<UrineInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UrineInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UrineInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
