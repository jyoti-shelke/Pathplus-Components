import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Urine} from '../urine';
import {Subscription} from 'rxjs/Subscription';
import {UrineService} from '../urine.service';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { User } from 'src/app/reports/user';
import { Report } from 'src/app/reports/report';
import { ReportService } from 'src/app/reports/report.service';

@Component({
  selector: 'app-urine-input',
  templateUrl: './urine-input.component.html',
  styleUrls: ['./urine-input.component.css']
})
export class UrineInputComponent implements OnInit, OnDestroy {

  //urine = new Urine();
  user: User;
  report: Report;
  sub: Subscription;

  formGroup: FormGroup;

  constructor(private builder: FormBuilder, private route: ActivatedRoute, private router: Router,
    private reportService: ReportService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params.id;
      if (id) {
        console.log('Selected report id ' + id);
        this.reportService.getReport(id)
          .subscribe(report => {
            this.report = report;
            this.report.doctorName = report.userName;
          });
        console.log(this.report);
      } else {
        this.report = this.reportService.getPlaceholderReports();
        this.report.testType = 'Urine';
        this.report.urine = new Urine();
      }
    });
    this.formGroup = new FormGroup({
      colour: new FormControl(),
      apprearance: new FormControl(),
      ph: new FormControl(),
      sgravity: new FormControl(),
      eplCells: new FormControl(),
      pusCells: new FormControl(),
      eplCast: new FormControl(),
      pusCellCast: new FormControl(),
      crystals: new FormControl(),
      bilePigment: new FormControl(),
      rbc: new FormControl(),
      other: new FormControl(),
      albumin: new FormControl(),
      sugar: new FormControl(),
      urobillinogen: new FormControl(),
      acetone: new FormControl(),
      bileSalt: new FormControl(),
      blood: new FormControl(),
      notes: new FormControl(),
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onSubmit() {
    this.report.userId = this.user.id;
    this.report.userName = this.user.name;
    this.report.userPhone = this.user.phone;
    this.report.doctorName = this.user.doctorName;
    console.log('Saving Report');
    this.reportService.saveReport(this.report).subscribe(result => {
      this.router.navigate(['/reports']);
    }, error => console.error(error));
  }
}
