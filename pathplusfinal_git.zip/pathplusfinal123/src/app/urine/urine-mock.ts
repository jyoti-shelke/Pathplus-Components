import { Urine } from './urine';

export const URINES: Urine[] = [
  {
    id: generateId(1000),
    colour: '1',
    apprearance: '1',
    ph: '1',
    sgravity: '1',
    eplCells: 1,
    pusCells: 1,
    eplCast: 1,
    pusCellCast: 1,
    crystals: 1,
    rbc: 1,
    other: 1,
    albumin: '1',
    sugar: '1',
    urobillinogen: '1',
    acetone: '1',
    bileSalt: '1',
    bilePigment: '1',
    blood: '1',
    notes: ''
  },
  {
    id: generateId(1000),
    colour: '2',
    apprearance: '2',
    ph: '2',
    sgravity: '2',
    eplCells: 1,
    pusCells: 1,
    eplCast: 1,
    pusCellCast: 1,
    crystals: 1,
    rbc: 1,
    other: 1,
    albumin: '2',
    sugar: '2',
    urobillinogen: '2',
    acetone: '2',
    bileSalt: '2',
    bilePigment: '2',
    blood: '2',
    notes: ''
  }
];

export function generateId(max) {
  return Math.floor(Math.random() * Math.floor(max));
}
