import { Widal } from './widal';

export const WIDALS: Widal[] = [
  {
    id: generateId(1000),
    sTyphiO: '1',
    sTyphiH: '1',
    sParatyphiTyphiAh: '1',
    sParatyphiTyphiBh: '1',
    impression: '1',
    montouxTestIoTuPpdInjected: '1',
    duration: '1',
    result: '1',
    s1A: '1',
    s2B: '1',
    grade: '1',
    notes: ''
  },
  {
    id: generateId(1000),
    sTyphiO: '1',
    sTyphiH: '1',
    sParatyphiTyphiAh: '1',
    sParatyphiTyphiBh: '1',
    impression: '1',
    montouxTestIoTuPpdInjected: '1',
    duration: '1',
    result: '1',
    s1A: '1',
    s2B: '1',
    grade: '1',
    notes: ''
  }
];

export function generateId(max) {
  return Math.floor(Math.random() * Math.floor(max));
}
