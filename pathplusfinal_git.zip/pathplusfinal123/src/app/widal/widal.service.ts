import { Injectable } from '@angular/core';
import {Widal} from './widal';
import {generateId, WIDALS} from './widal-mock';
import {Observable, of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WidalService {

  widals: Widal[] = WIDALS;

  constructor() {
  }

  getWidals(): Observable<Widal[]> {
    return of(this.widals);
  }

  getWidal(id: string): Observable<Widal> {
    const widal = this.widals.find(value => '' + value.id === id);
    return of(widal);
  }

  saveWidal(widal: Widal): Observable<string> {
    if (!widal.id) {
      widal.id = generateId(1000);
      this.widals.push(widal);
    } else {
      const index = this.widals.findIndex(value => value.id === widal.id);
      this.widals[index] = widal;
    }
    return of('Test Saved succesfully');
  }

  deleteWidal(id: number): Observable<string> {
    const index = this.widals.findIndex(value => value.id === id);
    this.widals.splice(index, 1);
    return of('Test deleted succesfully');
  }
}
