import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WidalViewComponent } from './widal-view.component';

describe('WidalViewComponent', () => {
  let component: WidalViewComponent;
  let fixture: ComponentFixture<WidalViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WidalViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WidalViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
