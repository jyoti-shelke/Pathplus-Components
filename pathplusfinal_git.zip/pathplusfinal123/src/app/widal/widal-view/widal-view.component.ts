import { Component, OnInit, OnDestroy } from '@angular/core';
import { Widal } from '../widal';
import { Report } from 'src/app/reports/report';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { WidalService } from '../widal.service';
import { ReportService } from 'src/app/reports/report.service';

@Component({
  selector: 'app-widal-view',
  templateUrl: './widal-view.component.html',
  styleUrls: ['./widal-view.component.css']
})
export class WidalViewComponent implements OnInit, OnDestroy  {
  widal = new Widal();
  report = new Report();

  sub: Subscription;

  constructor(private route: ActivatedRoute, private router: Router,
              private widalService: WidalService, private reportService: ReportService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params.id;
      if (id) {
        console.log('Selected id ' + id);
        this.widalService.getWidal(id)
          .subscribe(selectedWidal => this.widal = selectedWidal);

        this.reportService.getReport(id)
          .subscribe(selectedReport => this.report = selectedReport);
      }
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
