import { Widal } from './widal';

describe('Widal', () => {
  it('should create an instance', () => {
    expect(new Widal()).toBeTruthy();
  });
});
