import { TestBed } from '@angular/core/testing';

import { WidalService } from './widal.service';

describe('WidalService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WidalService = TestBed.get(WidalService);
    expect(service).toBeTruthy();
  });
});
