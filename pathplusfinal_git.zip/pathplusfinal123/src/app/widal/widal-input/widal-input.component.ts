import { Component, OnDestroy, OnInit } from '@angular/core';
import { Widal } from '../widal';
import { Subscription } from 'rxjs';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { WidalService } from '../widal.service';
import { User } from 'src/app/reports/user';
import { Report } from 'src/app/reports/report';
import { ReportService } from 'src/app/reports/report.service';

@Component({
  selector: 'app-widal-input',
  templateUrl: './widal-input.component.html',
  styleUrls: ['./widal-input.component.css']
})
export class WidalInputComponent implements OnInit, OnDestroy {

  user: User;
  report: Report;
  sub: Subscription;

  formGroup: FormGroup;

  constructor(private builder: FormBuilder, private route: ActivatedRoute, private router: Router,
    private reportService: ReportService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params.id;
      if (id) {
        console.log('Selected report id ' + id);
        this.reportService.getReport(id)
          .subscribe(report => {
            this.report = report;
            this.report.doctorName = report.userName;
          });
        console.log(this.report);
      } else {
        this.report = this.reportService.getPlaceholderReports();
        this.report.testType = 'Widal';
        this.report.widal = new Widal();
      }
    });
    this.formGroup = new FormGroup({

      sTyphiO: new FormControl(),
      sTyphiH: new FormControl(),
      sParatyphiTyphiAh: new FormControl(),
      sParatyphiTyphiBh: new FormControl(),
      impression: new FormControl(),
      montouxTestIoTuPpdInjected: new FormControl(),
      duration: new FormControl(),
      result: new FormControl(),
      s1A: new FormControl(),
      s2B: new FormControl(),
      grade: new FormControl(),
      notes: new FormControl(),
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  onSubmit() {
    this.report.userId = this.user.id;
    this.report.userName = this.user.name;
    this.report.userPhone = this.user.phone;
    this.report.doctorName = this.user.doctorName;
    console.log('Saving Report');
    this.reportService.saveReport(this.report).subscribe(result => {
      this.router.navigate(['/reports']);
    }, error => console.error(error));
  }

}
