import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WidalInputComponent } from './widal-input.component';

describe('WidalInputComponent', () => {
  let component: WidalInputComponent;
  let fixture: ComponentFixture<WidalInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WidalInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WidalInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
