export class Widal {

  id: number;
  sTyphiO: string;
  sTyphiH: string;
  sParatyphiTyphiAh: string;
  sParatyphiTyphiBh: string;
  impression: string;
  montouxTestIoTuPpdInjected: string;
  duration: string;
  result: string;
  s1A: string;
  s2B: string;
  grade: string;

  notes: string;

}
  