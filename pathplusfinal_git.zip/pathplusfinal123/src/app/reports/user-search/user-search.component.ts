import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {User} from '../user';
import {Subscription} from 'rxjs';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {UserSearchService} from '../user-search.service';
import {Report} from '../report';
import {ReportService} from '../report.service';

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.css']
})
export class UserSearchComponent implements OnInit, OnDestroy {

  @Input()
  report: Report;

  @Output() messageEvent = new EventEmitter<User>();

  user = new User();

  userSaved = false;

  addUser = false;

  userFound = false;

  editUser = false;

  sub: Subscription;

  formGroup: FormGroup;

  constructor(private builder: FormBuilder, private route: ActivatedRoute, private router: Router,
              private userService: UserSearchService, private reportService: ReportService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params.id;
      console.log(params);
      if (id) {
        this.reportService.getReport(id)
          .subscribe(selectedReport => {
            this.report = selectedReport;
            this.userService.getUser(selectedReport.userId)
              .subscribe(selectedUser => {
                this.user = selectedUser;
                this.userFound = true;
                this.editUser = true;
                this.messageEvent.emit(this.user);
                console.log('Edit user : ' + this.editUser);
              });
          });
        console.log('Selected user id ' + this.user.id);
        console.log(this.user);
      } else {
        console.log('New user in users component');
        console.log(this.report);
        this.user = new User();
      }
    });
    this.formGroup = new FormGroup({
      name: new FormControl(),
      phone: new FormControl(),
      email: new FormControl(),
      age: new FormControl(),
      doctorName: new FormControl(),
      // dob: new FormControl(this.user.dob ? this.user.dob : new Date())
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  searchUser() {
    this.userService.getUserUsingPhone(this.user.phone).subscribe(result => {
      if (result) {
        this.user = result;
        this.userFound = true;
        this.messageEvent.emit(this.user);
      } else {
        this.addUser = true;
      }
    }, error => console.error(error));
  }

  onUserSubmit() {
    console.log('Save user');
    this.userService.saveUser(this.user)
      .subscribe(result => {
        this.userSaved = true;
        this.messageEvent.emit(this.user);
      }, error => console.error(error));
  }
}
