import { Tuberculosisrt } from '../tuberculosis/tuberculosisrt';
import { Haemogram } from '../haemogram/haemogram';
import { Malariart } from '../malariart/malariart';
import { Prothrombin } from '../prothrombin/prothrombin';
import { Diabetic } from '../diabetic/diabetic';
import { Urine } from '../urine/urine';
import { Hbsagrt } from '../hbsag/hbsagrt';
import { Widal } from '../widal/widal';
import { Biochemistry } from '../biochemistry/biochemistry';

export class Report {
  id: string;
  testType: string;
  userId: string;
  userName: string;
  userPhone: string;
  doctorId: string;
  doctorName: string;
  labId: string;
  labName: string;
  technicianId: string;
  technicianName: string;
  creationDateTime: Date;
  notes: string;
  tuberculosisrt: Tuberculosisrt;
  malariart: Malariart;
  haemogram: Haemogram;
  prothrombin: Prothrombin;
  diabetic: Diabetic;
  urine: Urine;
  hbsagrt: Hbsagrt;
  widal: Widal;
  biochemistry: Biochemistry;

}
