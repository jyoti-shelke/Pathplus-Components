import {Injectable} from '@angular/core';
import {User} from './user';
import {generateId, USERS} from './user-mock';
import {Observable, of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserSearchService {

  users: User[] = USERS;

  constructor() {
  }

  getUsers(): Observable<User[]> {
    return of(this.users);
  }

  getUserUsingPhone(phone: string): Observable<User> {
    const user = this.users.find(value => value.phone === phone);
    if (user) {
      console.log('found user for phone: ' + phone);
    }
    return of(user);
  }

  getUser(id: string): Observable<User> {
    const user = this.users.find(value => value.id === id);
    return of(user);
  }

  saveUser(user: User): Observable<string> {
    if (!user.id) {
      user.id = generateId(1000);
      this.users.push(user);
    } else {
      const index = this.users.findIndex(value => value.id === user.id);
      this.users[index] = user;
    }
    return of('User Saved succesfully');
  }
}
