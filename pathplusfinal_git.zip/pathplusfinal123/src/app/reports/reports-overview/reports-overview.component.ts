import {Component, OnInit} from '@angular/core';
import {MatTableDataSource} from '@angular/material';
import {Report} from '../report';
import {ReportService} from '../report.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-reports-overview',
  templateUrl: './reports-overview.component.html',
  styleUrls: ['./reports-overview.component.css']
})
export class ReportsOverviewComponent implements OnInit {

  reports: Report[];

  displayedColumns = ['id', 'userName', 'userPhone', 'testType', 'doctorName', 'technicianName', 'creationDateTime', 'edit'];

  dataSource: MatTableDataSource<Report>;

  constructor(private router: Router, private reportService: ReportService) {
  }

  ngOnInit() {
    this.reportService.getReports()
      .subscribe(reports => this.reports = reports);
    this.dataSource = new MatTableDataSource(this.reports);
  }

  deleteTest(id: string) {
    this.reportService.deleteReport(id)
      .subscribe(result => {
        this.ngOnInit();
      }, error => console.error(error));
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
}
