import { User } from './user';

export const USERS: User[] = [
  {
    id: '1',
    name: 'Amit Deore',
    phone: '+919999999999',
    email: 'amit.deore@gmail.com',
    age: 40,
    doctorName: "Self"
  },
  {
    id: '2',
    name: 'Tejas Patil',
    phone: '+919888888888',
    email: 'amit.deore@gmail.com',
    age: 32,
    doctorName: "Self"
  }
];

export function generateId(max) {
  return '' + Math.floor(Math.random() * Math.floor(max));
}
