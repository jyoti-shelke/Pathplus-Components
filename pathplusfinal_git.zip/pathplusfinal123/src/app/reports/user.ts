export class User {

  id: string;
  name: string;
  phone: string;
  email: string;
  age: number;
  doctorName: string;
}
