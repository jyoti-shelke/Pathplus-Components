import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {of} from 'rxjs/observable/of';
import {Report} from './report';
import {generateId, REPORTS} from './report-mock';
import { Diabetic } from '../diabetic/diabetic';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  reports: Report[] = REPORTS;
  
  constructor() {
  }

  getReports(): Observable<Report[]> {
    return of(this.reports);
  }

  getPlaceholderReports(): Report {
    const report: Report = new Report();
    report.doctorId = '2';
    report.labId = '1';
    report.labName = 'NextCare';
    report.technicianId = '1';
    report.technicianName = 'Mr. Ravi Kumar';
    report.creationDateTime = new Date();
   
    return report;
  }

  getReport(id: string): Observable<Report> {
    console.log('Getting report for id : ' + id);
    const report = this.reports.find(value => value.id === id);
    console.log(report);
    return of(report);
  }

  saveReport(report: Report): Observable<string> {
    if (!report.id) {
      console.log(report);
      report.id = generateId(1000);
      this.reports.push(report);
      console.log('Report Saved succesfully');
    } else {
      const index = this.reports.findIndex(value => value.id === report.id);
      this.reports[index] = report;
    }
    return of('Report Saved succesfully');
  }

  deleteReport(id: string): Observable<string> {
    const index = this.reports.findIndex(value => value.id === id);
    this.reports.splice(index, 1);
    return of('Test deleted succesfully');
  }
}
