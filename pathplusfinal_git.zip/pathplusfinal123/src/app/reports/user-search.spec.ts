import { User } from './user';

describe('UserSearch', () => {
  it('should create an instance', () => {
    expect(new User()).toBeTruthy();
  });
});
