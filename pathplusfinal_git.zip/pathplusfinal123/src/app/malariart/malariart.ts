export class Malariart {

  id: number;
  pbsforPm: string;
  pVivax: string;
  pFalciparum: string;
  lotNo: number;
  bNo: number;
  mfg: number;
  expDate: string;
  sTyphiO:number;
  sTyphiH:number;

  notes: string;

}
