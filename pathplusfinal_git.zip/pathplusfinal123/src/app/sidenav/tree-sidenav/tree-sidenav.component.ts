import { Component, OnInit } from '@angular/core';
import {Biochemistry} from '../../biochemistry/biochemistry';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
    // { path: '/reports', title: 'Dashboard',  icon: 'dashboard', class: '' },
    { path: '/reports', title: 'Reports',  icon: 'dashboard', class: '' },
    { path: '/tuberculosisrt', title: 'Tuberculosis Rapid',  icon: 'library_books', class: '' },
    { path: '/haemogram', title: 'Haemogram',  icon: 'library_books', class: '' },
    { path: '/diabetic', title: 'Diabetic',  icon: 'library_books', class: '' },
    { path: '/malariart', title: 'Malaria',  icon: 'library_books', class: '' },
    { path: '/hiv', title: 'HIV',  icon: 'library_books', class: '' },
    { path: '/urine', title: 'Urine',  icon: 'library_books', class: '' },
    { path: '/prothrombin', title: 'Prothrombin',  icon: 'library_books', class: '' },
    { path: '/widal', title: 'Widal',  icon: 'library_books', class: '' },
    { path: '/hbsagrt', title: 'HBSAG Rapid Test',  icon: 'library_books', class: '' },
    { path: '/biochemistry', title: 'Biochemistry',  icon: 'library_books', class: '' },
    // { path: '/cardic-troponian', title: 'Cardic Troponian',  icon: 'library_books', class: '' },
    { path: '/urine', title: 'Notifications',  icon: 'notifications', class: '' }
];

@Component({
  selector: 'app-tree-sidenav',
  templateUrl: './tree-sidenav.component.html',
  styleUrls: ['./tree-sidenav.component.css']
})
export class TreeSidenavComponent implements OnInit {
  menuItems: any[];

  constructor() { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  }

  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  }
}
