import { CardicTroponian } from './cardic-troponian';

describe('CardicTroponian', () => {
  it('should create an instance', () => {
    expect(new CardicTroponian()).toBeTruthy();
  });
});
