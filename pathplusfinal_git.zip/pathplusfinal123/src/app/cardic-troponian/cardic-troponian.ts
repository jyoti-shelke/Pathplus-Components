export class CardicTroponian {

  id: number;
  paramI: string;
  paramII: string;
  notes: string;

}
