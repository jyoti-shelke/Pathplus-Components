export class Diabetic {

  id: number;
  fBloodSugar: number;
  fUrineSugar: number;
  fAcetone: string;
  ppBloodSugar: number;
  ppUrineSugar: number;
  ppAcetone: string;
  randomBloodS: number;
  randomUrineS: number;
  randomAcetone: string;
  gtt1: number;
  urineSugar: number;
  ketone: string;
  gtt2: number;
  urineSugar1: number;
  ketone1: string;
  notes: string;

}
