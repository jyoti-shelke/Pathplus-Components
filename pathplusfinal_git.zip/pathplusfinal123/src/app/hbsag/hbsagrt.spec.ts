import { Hbsagrt } from './hbsagrt';

describe('Hbsagrt', () => {
  it('should create an instance', () => {
    expect(new Hbsagrt()).toBeTruthy();
  });
});
