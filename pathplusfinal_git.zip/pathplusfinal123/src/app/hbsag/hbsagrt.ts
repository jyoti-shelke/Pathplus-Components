export class Hbsagrt {

  id: number;
  result: string;
  method: string;
  lotNo: string;
  bNo: number;
  mfg: number;
  expDate: string;
  notes: string;

}
