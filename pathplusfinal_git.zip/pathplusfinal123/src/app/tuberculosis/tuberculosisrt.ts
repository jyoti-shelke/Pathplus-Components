export class Tuberculosisrt {

  id: string;
  tuberculosisIgG: string;
  tuberculosisIgM: string;
  notes: string;

}
