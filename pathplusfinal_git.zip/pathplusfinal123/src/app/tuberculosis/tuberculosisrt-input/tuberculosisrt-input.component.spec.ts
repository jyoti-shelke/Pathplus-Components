import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TuberculosisrtInputComponent } from './tuberculosisrt-input.component';

describe('TuberculosisrtInputComponent', () => {
  let component: TuberculosisrtInputComponent;
  let fixture: ComponentFixture<TuberculosisrtInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TuberculosisrtInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TuberculosisrtInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
