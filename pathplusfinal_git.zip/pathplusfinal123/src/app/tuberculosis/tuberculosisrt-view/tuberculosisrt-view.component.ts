import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {TuberculosisrtService} from '../tuberculosisrt.service';
import {Tuberculosisrt} from '../tuberculosisrt';
import {Subscription} from 'rxjs';
import {ReportService} from '../../reports/report.service';
import {Report} from '../../reports/report';

@Component({
  selector: 'app-tuberculosis-view',
  templateUrl: './tuberculosisrt-view.component.html',
  styleUrls: ['./tuberculosisrt-view.component.css']
})
export class TuberculosisrtViewComponent implements OnInit, OnDestroy {

  tuberculosisrt = new Tuberculosisrt();
  report = new Report();

  sub: Subscription;

  constructor(private route: ActivatedRoute, private router: Router,
              private tuberculosisrtService: TuberculosisrtService, private reportService: ReportService) {
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params.id;
      if (id) {
        console.log('Selected id ' + id);
        this.tuberculosisrtService.getTuberculosisrt(id)
          .subscribe(selectedTuberculosisrt => this.tuberculosisrt = selectedTuberculosisrt);

        this.reportService.getReport(id)
          .subscribe(selectedReport => this.report = selectedReport);
      }
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
