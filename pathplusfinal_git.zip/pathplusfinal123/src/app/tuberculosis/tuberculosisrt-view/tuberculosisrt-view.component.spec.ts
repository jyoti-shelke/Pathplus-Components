import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TuberculosisrtViewComponent } from './tuberculosisrt-view.component';

describe('TuberculosisViewComponent', () => {
  let component: TuberculosisrtViewComponent;
  let fixture: ComponentFixture<TuberculosisrtViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TuberculosisrtViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TuberculosisrtViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
