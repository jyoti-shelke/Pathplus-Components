import { Tuberculosisrt } from './tuberculosisrt';

export const TUBERCULOSISRTS: Tuberculosisrt[] = [
  {
    id: generateId(1000),
    tuberculosisIgG: '1',
    tuberculosisIgM: '1',
    notes: ''
  },
  {
    id: generateId(1000),
    tuberculosisIgG: '1',
    tuberculosisIgM: '1',
    notes: ''
  }
];

export function generateId(max) {
  return '' + Math.floor(Math.random() * Math.floor(max));
}
