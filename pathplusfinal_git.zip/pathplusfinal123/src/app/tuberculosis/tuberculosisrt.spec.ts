import { Tuberculosisrt } from './tuberculosisrt';

describe('Tuberculosisr', () => {
  it('should create an instance', () => {
    expect(new Tuberculosisrt()).toBeTruthy();
  });
});
