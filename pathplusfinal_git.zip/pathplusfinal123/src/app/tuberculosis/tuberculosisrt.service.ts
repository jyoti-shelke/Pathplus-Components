import {Injectable} from '@angular/core';
import {Tuberculosisrt} from './tuberculosisrt';
import {generateId, TUBERCULOSISRTS} from './tuberculosisrt-mock';
import {Observable, of} from 'rxjs';
import {Report} from '../reports/report';
import {REPORTS} from '../reports/report-mock';
import {ReportService} from '../reports/report.service';

@Injectable({ 
  providedIn: 'root'
})
export class TuberculosisrtService {

  tuberculosisrts: Tuberculosisrt[] = TUBERCULOSISRTS;
  reports: Report[] = REPORTS;

  constructor(private reportService: ReportService) {
  }

  getTuberculosisrts(): Observable<Tuberculosisrt[]> {
    return of(this.tuberculosisrts);
  }

  getTuberculosisrt(id: string): Observable<Tuberculosisrt> {
    const tuberculosisrt = this.tuberculosisrts.find(value => '' + value.id === id);
    return of(tuberculosisrt);
  }

  saveTuberculosisrt(tuberculosisrt: Tuberculosisrt): Observable<string> {
    if (!tuberculosisrt.id) {
      tuberculosisrt.id = generateId(1000);
      this.tuberculosisrts.push(tuberculosisrt);
      const report = this.reportService.getPlaceholderReports();
      report.id = tuberculosisrt.id;
      report.testType = 'TuberculosisRT';
      report.userName = report.userName;
      report.userPhone = report.userPhone;
      report.creationDateTime = new Date();
      report.tuberculosisrt = tuberculosisrt;
      console.log(report);
      this.reports.push(report);
    } else {
      const index = this.tuberculosisrts.findIndex(value => value.id === tuberculosisrt.id);
      this.tuberculosisrts[index] = tuberculosisrt;
    }
    return of('Test Saved succesfully');
  }

  deleteTuberculosisrt(id: string): Observable<string> {
    const index = this.tuberculosisrts.findIndex(value => value.id === id);
    this.tuberculosisrts.splice(index, 1);
    return of('Test deleted succesfully');
  }
}
