import { TestBed } from '@angular/core/testing';

import { TuberculosisrtService } from './tuberculosisrt.service';

describe('TuberculosisrtService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TuberculosisrtService = TestBed.get(TuberculosisrtService);
    expect(service).toBeTruthy();
  });
});
  