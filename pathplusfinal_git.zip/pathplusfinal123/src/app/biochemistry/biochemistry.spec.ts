import { Biochemistry } from './biochemistry';

describe('Biochemistry', () => {
  it('should create an instance', () => {
    expect(new Biochemistry()).toBeTruthy();
  });
});
