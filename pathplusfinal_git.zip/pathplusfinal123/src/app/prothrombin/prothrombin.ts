export class Prothrombin {

  id: number;
  controlTime: number;
  patientTime: number;
  internationalNormalRatio: number;
  notes: string;

}
